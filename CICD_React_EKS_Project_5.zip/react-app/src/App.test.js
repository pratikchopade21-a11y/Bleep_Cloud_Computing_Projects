import { render, screen } from '@testing-library/react';
import App from './App';

test('renders pipeline heading', () => {
  render(<App />);
  const heading = screen.getByText(/End-to-End CI\/CD Pipeline Demo/i);
  expect(heading).toBeInTheDocument();
});
