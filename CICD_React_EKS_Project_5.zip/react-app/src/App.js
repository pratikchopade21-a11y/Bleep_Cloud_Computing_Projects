import React from 'react';

function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', textAlign: 'center', marginTop: '80px' }}>
      <h1>End-to-End CI/CD Pipeline Demo</h1>
      <p>React App deployed via Jenkins → Docker → Trivy → SonarQube → EKS</p>
    </div>
  );
}

export default App;
