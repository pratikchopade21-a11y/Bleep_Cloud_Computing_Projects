# End-to-End CI/CD Pipeline for React Application
### Jenkins · Docker · SonarQube · Trivy · Terraform · Amazon EKS

## Objective
Automated pipeline that builds, tests, scans, containerizes, and deploys a React application to Amazon EKS.

## Repository Structure
```
.
├── Jenkinsfile                 # 15-stage declarative pipeline
├── react-app/                  # React application source
│   ├── src/
│   │   ├── App.js
│   │   ├── App.test.js
│   │   ├── index.js
│   │   └── setupTests.js
│   ├── public/index.html
│   ├── package.json
│   ├── Dockerfile              # Multi-stage build (Node -> nginx)
│   ├── nginx.conf
│   ├── .dockerignore
│   └── sonar-project.properties
├── terraform/                  # Infrastructure as Code
│   ├── provider.tf
│   ├── variables.tf
│   ├── vpc.tf                  # VPC, subnets, IGW, NAT, route tables
│   ├── security_groups.tf
│   ├── iam.tf                  # Cluster & node IAM roles
│   ├── eks.tf                  # EKS cluster + managed node group
│   └── outputs.tf
└── k8s/                        # Kubernetes manifests
    ├── deployment.yaml
    ├── service.yaml
    └── ingress.yaml (optional)
```

## Prerequisites
- Jenkins server with: NodeJS, Docker, SonarQube Scanner, and Kubernetes CLI plugins
- Docker installed on the Jenkins agent
- SonarQube server running and reachable from Jenkins
- Trivy installed on the Jenkins agent
- AWS CLI v2 configured (or Jenkins AWS credentials plugin)
- kubectl installed
- Terraform >= 1.5.0
- Docker Hub account
- AWS account with permissions to create VPC/EKS resources

## Step 1 — Provision Infrastructure with Terraform
```bash
cd terraform
terraform init
terraform plan
terraform apply -auto-approve
```
This creates: VPC, public/private subnets, Internet Gateway, NAT Gateway, route tables, security groups, IAM roles, the EKS cluster, and a managed node group.

Update kubeconfig locally to verify:
```bash
aws eks update-kubeconfig --region us-east-1 --name cicd-demo-cluster
kubectl get nodes
```

## Step 2 — Configure Jenkins Credentials
In Jenkins, add these credentials:
| ID | Type | Purpose |
|---|---|---|
| `dockerhub-creds` | Username/Password | Docker Hub login |
| `aws-creds` | AWS Credentials | EKS/AWS CLI access |

Also configure a SonarQube server in **Manage Jenkins → System → SonarQube servers** named `SonarQube`, matching the Jenkinsfile's `SONARQUBE_ENV`.

## Step 3 — Update Placeholders
In `Jenkinsfile`, replace:
- `yourdockerhubuser/cicd-react-app` with your actual Docker Hub repo
- `us-east-1` / `cicd-demo-cluster` if you changed Terraform variables

## Step 4 — Run the Pipeline
Create a Jenkins Pipeline job pointing at this repo's `Jenkinsfile`. On each build, the pipeline executes:

1. **Checkout** — pulls source from GitHub
2. **Clean Workspace** — removes stale `node_modules`/`build`
3. **Install Dependencies** — `npm ci`
4. **Unit Testing** — `npm test` with coverage
5. **Build React Application** — `npm run build`
6. **SonarQube Code Scan** — static analysis via `sonar-scanner`
7. **Quality Gate** — pipeline aborts if SonarQube gate fails
8. **Docker Build** — multi-stage image build
9. **Trivy Image Scan** — fails build on HIGH/CRITICAL vulnerabilities
10. **Docker Push** — pushes tagged + `latest` image to Docker Hub
11. **Configure AWS CLI** — verifies AWS identity
12. **Connect to Amazon EKS** — updates kubeconfig
13. **Deploy using Kubernetes Manifests** — `kubectl apply` deployment + service
14. **Verify Rollout** — `kubectl rollout status`
15. **Health Check** — confirms pods/service are healthy

## Step 5 — Access the Application
```bash
kubectl get svc cicd-react-app-service
```
Use the `EXTERNAL-IP` from the LoadBalancer to open the app in your browser.

## Tearing Down
```bash
kubectl delete -f k8s/
cd terraform
terraform destroy -auto-approve
```

## Interview Highlights (from project brief)
Be ready to explain:
- Jenkins stages and why each exists in this order
- SonarQube Quality Gate (what it checks, why it can block a deploy)
- Trivy scanning (image vulnerability scanning, severity thresholds)
- Docker image lifecycle (build → scan → push → pull → run)
- Terraform provisioning (state, plan/apply, IAM least-privilege roles)
- EKS deployment (control plane vs. managed node groups, networking)
- Kubernetes rollout verification (readiness/liveness probes, rolling updates)

## Notes / Things to Customize
- The Terraform default region is `us-east-1` with 2 AZs — adjust `variables.tf` for your account.
- `ingress.yaml` assumes the AWS Load Balancer Controller is installed on the cluster; it's optional — the `Service` of type `LoadBalancer` alone is enough to expose the app.
- For production, move Terraform state to an S3 backend with DynamoDB locking (commented block in `provider.tf`).
- Consider adding a private ECR repo instead of Docker Hub if you want registry access tied to IAM.
