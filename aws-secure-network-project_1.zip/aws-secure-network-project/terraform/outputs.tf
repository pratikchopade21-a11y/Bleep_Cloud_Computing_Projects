output "vpc_id" {
  description = "ID of the created VPC"
  value       = aws_vpc.main.id
}

output "public_subnet_id" {
  value = aws_subnet.public.id
}

output "private_subnet_id" {
  value = aws_subnet.private.id
}

output "web_server_public_ip" {
  description = "Public IP of the Nginx web server - open this in a browser"
  value       = aws_instance.web.public_ip
}

output "bastion_public_ip" {
  description = "Public IP of the bastion host - SSH here first"
  value       = aws_instance.bastion.public_ip
}

output "db_server_private_ip" {
  description = "Private IP of the database server - only reachable from inside the VPC"
  value       = aws_instance.db.private_ip
}

output "ssh_key_note" {
  description = "How to SSH in"
  value       = var.key_name == "" ? "A new key pair was generated: terraform/generated_key.pem (chmod 400 it before use)" : "Using your existing key pair: ${var.key_name}"
}

output "ssh_bastion_command" {
  value = var.key_name == "" ? "ssh -i generated_key.pem ec2-user@${aws_instance.bastion.public_ip}" : "ssh -i /path/to/${var.key_name}.pem ec2-user@${aws_instance.bastion.public_ip}"
}
