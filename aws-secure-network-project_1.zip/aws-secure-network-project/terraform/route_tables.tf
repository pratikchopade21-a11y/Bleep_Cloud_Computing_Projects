# -----------------------------------------------------------------------------
# STEP 5: Configure Route Tables
# -----------------------------------------------------------------------------

# Public Route Table -> sends all internet-bound traffic (0.0.0.0/0) to the IGW
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }

  tags = {
    Name = "${var.project_name}-public-rt"
  }
}

resource "aws_route_table_association" "public" {
  subnet_id      = aws_subnet.public.id
  route_table_id = aws_route_table.public.id
}

# Private Route Table -> NO route to the Internet Gateway.
# Only the default "local" route (10.0.0.0/16) exists, which AWS adds
# automatically. This is what keeps the database subnet unreachable
# from the internet.
resource "aws_route_table" "private" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = "${var.project_name}-private-rt"
  }
}

resource "aws_route_table_association" "private" {
  subnet_id      = aws_subnet.private.id
  route_table_id = aws_route_table.private.id
}
