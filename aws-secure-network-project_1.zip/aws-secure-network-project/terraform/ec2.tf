# -----------------------------------------------------------------------------
# STEP 6: Launch Web Server, Bastion Host, and Database Server
# -----------------------------------------------------------------------------

# Latest Amazon Linux 2023 AMI (free-tier eligible)
data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# --- Key Pair -----------------------------------------------------------------
# If var.key_name is empty, generate a brand-new key pair automatically so the
# project works out of the box. Otherwise, reuse an existing key pair you own.
resource "tls_private_key" "generated" {
  count     = var.key_name == "" ? 1 : 0
  algorithm = "RSA"
  rsa_bits  = 4096
}

resource "aws_key_pair" "generated" {
  count      = var.key_name == "" ? 1 : 0
  key_name   = "${var.project_name}-key"
  public_key = tls_private_key.generated[0].public_key_openssh
}

resource "local_file" "private_key" {
  count           = var.key_name == "" ? 1 : 0
  content         = tls_private_key.generated[0].private_key_pem
  filename        = "${path.module}/generated_key.pem"
  file_permission = "0400"
}

locals {
  key_name = var.key_name != "" ? var.key_name : aws_key_pair.generated[0].key_name
}

# --- Bastion Host (public subnet) ---------------------------------------------
resource "aws_instance" "bastion" {
  ami                         = data.aws_ami.amazon_linux.id
  instance_type               = var.instance_type
  subnet_id                   = aws_subnet.public.id
  vpc_security_group_ids      = [aws_security_group.bastion_sg.id]
  key_name                    = local.key_name
  associate_public_ip_address = true

  tags = {
    Name = "${var.project_name}-bastion-host"
  }
}

# --- Web Server (public subnet, runs Nginx) -----------------------------------
resource "aws_instance" "web" {
  ami                         = data.aws_ami.amazon_linux.id
  instance_type               = var.instance_type
  subnet_id                   = aws_subnet.public.id
  vpc_security_group_ids      = [aws_security_group.web_sg.id]
  key_name                    = local.key_name
  associate_public_ip_address = true
  user_data                   = file("${path.module}/user_data/web_server.sh")

  tags = {
    Name = "${var.project_name}-web-server"
  }
}

# --- Database Server (private subnet, runs MySQL) -----------------------------
resource "aws_instance" "db" {
  ami                         = data.aws_ami.amazon_linux.id
  instance_type               = var.instance_type
  subnet_id                   = aws_subnet.private.id
  vpc_security_group_ids      = [aws_security_group.db_sg.id]
  key_name                    = local.key_name
  associate_public_ip_address = false
  user_data = templatefile("${path.module}/user_data/db_server.sh", {
    db_username = var.db_username
    db_password = var.db_password
    db_name     = var.db_name
  })

  tags = {
    Name = "${var.project_name}-db-server"
  }
}
