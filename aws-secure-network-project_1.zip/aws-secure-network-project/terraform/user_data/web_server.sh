#!/bin/bash
# Bootstraps the Nginx web server on first boot (Amazon Linux 2023)
set -e

dnf update -y
dnf install -y nginx mysql

cat > /usr/share/nginx/html/index.html <<'EOF'
<!DOCTYPE html>
<html>
<head><title>Secure AWS Network - Web Server</title></head>
<body style="font-family: sans-serif; text-align:center; margin-top:10%;">
  <h1>It works!</h1>
  <p>This page is served from the public subnet's Nginx Web Server.</p>
  <p>Deployed as part of the Secure AWS Network Infrastructure project.</p>
</body>
</html>
EOF

systemctl enable nginx
systemctl start nginx
