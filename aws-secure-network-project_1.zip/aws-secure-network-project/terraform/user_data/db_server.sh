#!/bin/bash
# Bootstraps MySQL (MariaDB) on the private database server (Amazon Linux 2023)
set -e

dnf update -y
dnf install -y mariadb105-server

systemctl enable mariadb
systemctl start mariadb

# Wait for MySQL to be ready
sleep 5

mysql -u root <<SQL
CREATE DATABASE IF NOT EXISTS ${db_name};
CREATE USER IF NOT EXISTS '${db_username}'@'%' IDENTIFIED BY '${db_password}';
GRANT ALL PRIVILEGES ON ${db_name}.* TO '${db_username}'@'%';
FLUSH PRIVILEGES;
SQL

# Allow remote connections (bind-address 0.0.0.0) so the Web Server SG
# (already restricted at the network/SG/NACL layer) can reach it on 3306.
sed -i 's/^bind-address.*/bind-address = 0.0.0.0/' /etc/my.cnf.d/mariadb-server.cnf || \
  echo -e "[mysqld]\nbind-address = 0.0.0.0" >> /etc/my.cnf.d/mariadb-server.cnf

systemctl restart mariadb
