variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Prefix used to name/tag all resources"
  type        = string
  default     = "secure-net"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "public_subnet_cidr" {
  description = "CIDR block for the public subnet"
  type        = string
  default     = "10.0.1.0/24"
}

variable "private_subnet_cidr" {
  description = "CIDR block for the private subnet"
  type        = string
  default     = "10.0.2.0/24"
}

variable "availability_zone" {
  description = "Availability zone to place both subnets in"
  type        = string
  default     = "us-east-1a"
}

variable "my_ip" {
  description = "Your public IP address in CIDR form, e.g. 203.0.113.10/32. Used to lock down SSH. Get yours with: curl -s https://checkip.amazonaws.com"
  type        = string
  # No default on purpose - you MUST set this in terraform.tfvars
}

variable "instance_type" {
  description = "EC2 instance type for all three servers (free-tier eligible)"
  type        = string
  default     = "t2.micro"
}

variable "key_name" {
  description = "Name of an EXISTING AWS EC2 Key Pair to use for SSH. Leave blank to have Terraform generate a new key pair for you (saved locally as generated_key.pem)."
  type        = string
  default     = ""
}

variable "db_username" {
  description = "Master username for the MySQL database installed on the DB server"
  type        = string
  default     = "admin"
}

variable "db_password" {
  description = "Master password for the MySQL database installed on the DB server"
  type        = string
  sensitive   = true
  default     = "ChangeMe123!"
}

variable "db_name" {
  description = "Initial database schema name to create"
  type        = string
  default     = "appdb"
}
