# Implementation Steps (Manual / AWS Console Reference)

The Terraform code in `terraform/` automates every step below. This document
explains what each step does and how to do it by hand in the AWS Console, in
case you need to demonstrate the manual process (e.g. for a class/exam) or
just want to understand exactly what Terraform is creating for you.

## 1. Create VPC (10.0.0.0/16)
- AWS Console → VPC → "Create VPC"
- Name: `secure-net-vpc`
- IPv4 CIDR: `10.0.0.0/16`
- Tenancy: Default

## 2. Create Public Subnet (10.0.1.0/24)
- VPC → Subnets → "Create subnet"
- VPC: `secure-net-vpc`
- Name: `secure-net-public-subnet`
- Availability Zone: pick one, e.g. `us-east-1a`
- CIDR: `10.0.1.0/24`
- After creation: Actions → Edit subnet settings → Enable **"Auto-assign public IPv4 address"**

## 3. Create Private Subnet (10.0.2.0/24)
- VPC → Subnets → "Create subnet"
- Name: `secure-net-private-subnet`
- Same AZ as public subnet (or a different one for HA)
- CIDR: `10.0.2.0/24`
- Leave "Auto-assign public IPv4" **disabled**

## 4. Create and Attach Internet Gateway
- VPC → Internet Gateways → "Create internet gateway" → name it `secure-net-igw`
- Select it → Actions → "Attach to VPC" → choose `secure-net-vpc`

## 5. Configure Route Tables
**Public Route Table:**
- VPC → Route Tables → "Create route table" → name `secure-net-public-rt`, VPC `secure-net-vpc`
- Edit routes → Add route: Destination `0.0.0.0/0`, Target = the Internet Gateway
- Edit subnet associations → associate the **public** subnet

**Private Route Table:**
- Create another route table `secure-net-private-rt`
- Do **not** add a route to the Internet Gateway (only the automatic `local` route stays)
- Associate the **private** subnet

## 6. Launch Web Server, Bastion Host, and Database Server
Launch three EC2 instances (Amazon Linux 2023, t2.micro):

| Instance | Subnet | Public IP | Security Group | Purpose |
|---|---|---|---|---|
| Bastion Host | Public | Yes | bastion-sg | SSH jump box into the private network |
| Web Server | Public | Yes | web-sg | Runs Nginx |
| Database Server | Private | No | db-sg | Runs MySQL/MariaDB |

For the Web Server, add this as **User data** at launch (Advanced details):
see `terraform/user_data/web_server.sh`.

For the Database Server, use `terraform/user_data/db_server.sh` as a
reference (fill in your own DB name/user/password) as User data.

Continue to `security_groups.md` and `network_acls.md` for the exact firewall
rules to attach to each resource above.
