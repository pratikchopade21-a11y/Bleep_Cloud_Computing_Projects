# Security Groups

Security Groups are **stateful** virtual firewalls attached to EC2 instances
(the ENI, technically). "Stateful" means if you allow inbound traffic, the
response traffic is automatically allowed back out — you don't need a
matching outbound rule for replies.

## bastion-sg (attached to the Bastion Host)
| Direction | Port | Protocol | Source/Destination | Purpose |
|---|---|---|---|---|
| Inbound | 22 | TCP | Your IP (`my_ip`) only | SSH management access |
| Outbound | All | All | 0.0.0.0/0 | Allow the bastion to reach anything it needs to (e.g. hop to private subnet) |

## web-sg (attached to the Nginx Web Server)
| Direction | Port | Protocol | Source/Destination | Purpose |
|---|---|---|---|---|
| Inbound | 22 | TCP | Your IP (`my_ip`) only | Direct SSH for troubleshooting |
| Inbound | 80 | TCP | 0.0.0.0/0 | Public HTTP access to the website |
| Inbound | 443 | TCP | 0.0.0.0/0 | Public HTTPS access (if you add a cert later) |
| Outbound | All | All | 0.0.0.0/0 | Allow updates, package installs, DB queries |

## db-sg (attached to the Database Server)
| Direction | Port | Protocol | Source/Destination | Purpose |
|---|---|---|---|---|
| Inbound | 3306 | TCP | **web-sg** (by Security Group ID, not CIDR) | Only the web server may query the database |
| Inbound | 22 | TCP | **bastion-sg** (by Security Group ID) | Only the bastion may SSH into the DB server |
| Outbound | All | All | 0.0.0.0/0 | Allow OS updates etc. |

### Why reference Security Groups instead of IP ranges?
Referencing `web-sg` / `bastion-sg` as the *source* (instead of a CIDR block)
means the rule automatically follows the instances even if their IPs change,
and it can't accidentally be widened to an entire subnet or the internet by
mistake. This is a core AWS security best practice for tiered architectures.

### Why is there no rule for the database on 80/443 or open to 0.0.0.0/0?
Because the database should never be reachable from the internet at all —
that's the entire point of the private subnet + private route table + this
tightly-scoped Security Group working together (defense in depth).
