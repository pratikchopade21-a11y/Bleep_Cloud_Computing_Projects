# Network ACLs (NACLs)

NACLs are **stateless** virtual firewalls attached at the **subnet** level
(a second, coarser layer of defense behind Security Groups). Because they're
stateless, return traffic is NOT automatically allowed — you must explicitly
permit the ephemeral port range (1024–65535) in both directions so that
responses to requests can flow back through.

Rules are evaluated in order of rule number (lowest first); the first
matching rule wins.

## Public Subnet NACL
**Inbound:**
| Rule # | Port | Protocol | Source | Action |
|---|---|---|---|---|
| 100 | 22 | TCP | Your IP | ALLOW |
| 110 | 80 | TCP | 0.0.0.0/0 | ALLOW |
| 120 | 443 | TCP | 0.0.0.0/0 | ALLOW |
| 130 | 1024-65535 | TCP | 0.0.0.0/0 | ALLOW (ephemeral, for return traffic) |
| * | all | all | all | DENY (implicit default) |

**Outbound:**
| Rule # | Port | Protocol | Destination | Action |
|---|---|---|---|---|
| 100 | 80 | TCP | 0.0.0.0/0 | ALLOW |
| 110 | 443 | TCP | 0.0.0.0/0 | ALLOW |
| 120 | 22 | TCP | 10.0.2.0/24 (private subnet) | ALLOW (bastion → DB SSH) |
| 130 | 3306 | TCP | 10.0.2.0/24 (private subnet) | ALLOW (web → DB queries) |
| 140 | 1024-65535 | TCP | 0.0.0.0/0 | ALLOW (ephemeral, for return traffic) |
| * | all | all | all | DENY (implicit default) |

## Private Subnet NACL
**Inbound:**
| Rule # | Port | Protocol | Source | Action |
|---|---|---|---|---|
| 100 | 22 | TCP | 10.0.1.0/24 (public subnet) | ALLOW |
| 110 | 3306 | TCP | 10.0.1.0/24 (public subnet) | ALLOW |
| 120 | 1024-65535 | TCP | 10.0.1.0/24 (public subnet) | ALLOW (ephemeral, for return traffic) |
| * | all | all | all | DENY (implicit default) |

**Outbound:**
| Rule # | Port | Protocol | Destination | Action |
|---|---|---|---|---|
| 100 | 1024-65535 | TCP | 10.0.1.0/24 (public subnet) | ALLOW (ephemeral, for return traffic) |
| 110 | 22 | TCP | 10.0.1.0/24 (public subnet) | ALLOW |
| 120 | 3306 | TCP | 10.0.1.0/24 (public subnet) | ALLOW |
| * | all | all | all | DENY (implicit default) |

## Key takeaway: two layers of defense
1. **Security Groups** (stateful, instance-level) already prevent unwanted
   traffic to the database.
2. **NACLs** (stateless, subnet-level) add a second, independent layer: even
   if a Security Group were accidentally misconfigured, the private
   subnet's NACL still blocks anything other than SSH/MySQL from the public
   subnet's CIDR range. This is "defense in depth."
