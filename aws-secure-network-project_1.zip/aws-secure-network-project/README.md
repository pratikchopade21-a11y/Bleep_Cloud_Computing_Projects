# Secure AWS Network Infrastructure Project

## Project Objective
Design and implement a secure AWS network infrastructure using a VPC, Public and
Private Subnets, Security Groups, Route Tables, an Internet Gateway, and Network
ACLs (firewalls) — deployed automatically with Terraform.

## Architecture

```
                                   ┌───────────────────────────────────────────┐
                                   │                  VPC (10.0.0.0/16)          │
                                   │                                             │
 Internet ──► Internet Gateway ──►│  Public Route Table ──► Public Subnet       │
                                   │        (0.0.0.0/0→IGW)   (10.0.1.0/24)      │
                                   │                          ├── Nginx Web SVR  │
                                   │                          └── Bastion Host   │
                                   │                                             │
                                   │  Private Route Table ──► Private Subnet     │
                                   │        (local only)      (10.0.2.0/24)      │
                                   │                          └── Database Srv   │
                                   └───────────────────────────────────────────┘
```

Traffic flow:
`Internet → Internet Gateway → Public Route Table → Public Subnet (Nginx Web
Server + Bastion Host) → Private Route Table → Private Subnet (Database
Server)`

## AWS Services Used
VPC, Public Subnet, Private Subnet, Internet Gateway, Route Tables, Security
Groups, Network ACLs, EC2.

## Repository Layout
```
aws-secure-network-project/
├── README.md                     <- you are here
├── terraform/                    <- Infrastructure as Code (deploy with this)
│   ├── provider.tf
│   ├── variables.tf
│   ├── vpc.tf
│   ├── subnets.tf
│   ├── internet_gateway.tf
│   ├── route_tables.tf
│   ├── security_groups.tf
│   ├── network_acls.tf
│   ├── ec2.tf
│   ├── outputs.tf
│   ├── terraform.tfvars.example
│   └── user_data/
│       ├── web_server.sh
│       └── db_server.sh
├── scripts/
│   └── test_connectivity.sh      <- automated post-deploy testing
└── docs/
    ├── implementation_steps.md
    ├── security_groups.md
    └── network_acls.md
```

## Prerequisites
1. An AWS account with programmatic access (Access Key + Secret Key).
2. [Terraform](https://developer.hashicorp.com/terraform/install) >= 1.5 installed locally.
3. [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html) installed and configured (`aws configure`).
4. An existing EC2 Key Pair in the target region (for SSH access), OR let Terraform create one for you (see `variables.tf`).
5. Your current public IP address (for locking down SSH). Get it with:
   ```
   curl -s https://checkip.amazonaws.com
   ```

## Quick Start (Implementation Steps)

```bash
cd terraform

# 1. Copy the example variables file and edit it
cp terraform.tfvars.example terraform.tfvars
nano terraform.tfvars      # set my_ip, key_name, region, db_password etc.

# 2. Initialize Terraform (downloads AWS provider)
terraform init

# 3. Review the execution plan
terraform plan

# 4. Create the VPC (10.0.0.0/16)
# 5. Create Public Subnet (10.0.1.0/24) and Private Subnet (10.0.2.0/24)
# 6. Create and attach Internet Gateway
# 7. Configure Route Tables
# 8. Launch Web Server, Bastion Host, and Database Server
# ---> all of the above happen in one command:
terraform apply
```

Type `yes` when prompted. After a few minutes Terraform will print outputs
including the Web Server public IP, Bastion public IP, and DB private IP.

## Testing

Run the included test script (needs the Terraform outputs, or pass them
manually):

```bash
cd ../scripts
chmod +x test_connectivity.sh
./test_connectivity.sh
```

It will:
1. Curl the Nginx web page over the public internet (should succeed).
2. Attempt to reach the database server's MySQL port directly from your
   machine over the internet (should FAIL / time out — proves it's private).
3. SSH into the Bastion Host, then hop to the Database Server, and test
   `mysql` connectivity from there (should succeed).
4. From the Bastion, curl the Web Server's local Nginx port to confirm
   internal reachability.

See `docs/implementation_steps.md` for a manual, step-by-step walkthrough if
you'd rather do this via the AWS Console instead of Terraform, and
`docs/security_groups.md` / `docs/network_acls.md` for the exact firewall
rules and the reasoning behind them.

## Tearing Down
When you're done testing, avoid ongoing AWS charges:
```bash
cd terraform
terraform destroy
```

## Learning Outcomes
VPCs, Subnets, Route Tables, Internet Gateway, Security Groups, Network ACLs,
Bastion Host pattern, and multi-tier (public/private) architecture.

## Security Notes
- SSH (22) is restricted to your IP only — never leave it open to 0.0.0.0/0.
- The database has no public IP and no route to the Internet Gateway.
- Security Groups are stateful (return traffic auto-allowed); NACLs are
  stateless, so ephemeral port ranges (1024–65535) are explicitly opened for
  return traffic — see `docs/network_acls.md`.
- `terraform.tfvars` (containing your real IP/DB password) is git-ignored —
  never commit real secrets.
