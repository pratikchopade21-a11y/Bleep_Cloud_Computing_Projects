#!/bin/bash
# -----------------------------------------------------------------------------
# test_connectivity.sh
# Validates the secure AWS network project against its Testing requirements:
#   1. Access Nginx webpage over the internet          -> should SUCCEED
#   2. Verify private database is inaccessible from internet -> should FAIL/timeout
#   3. Connect via Bastion Host                         -> should SUCCEED
#   4. Test DB connectivity from Web Server              -> should SUCCEED
#
# Run this from the terraform/ directory's outputs, or export the vars below
# manually if you deployed via the AWS Console instead of Terraform.
# -----------------------------------------------------------------------------
set -uo pipefail

TF_DIR="$(dirname "$0")/../terraform"

get_output() {
  terraform -chdir="$TF_DIR" output -raw "$1" 2>/dev/null
}

WEB_IP="${WEB_IP:-$(get_output web_server_public_ip)}"
BASTION_IP="${BASTION_IP:-$(get_output bastion_public_ip)}"
DB_IP="${DB_IP:-$(get_output db_server_private_ip)}"
KEY_FILE="${KEY_FILE:-$TF_DIR/generated_key.pem}"
SSH_USER="${SSH_USER:-ec2-user}"

pass() { echo "  ✅ PASS: $1"; }
fail() { echo "  ❌ FAIL: $1"; }
info() { echo -e "\n== $1 =="; }

if [[ -z "$WEB_IP" || -z "$BASTION_IP" || -z "$DB_IP" ]]; then
  echo "Could not read Terraform outputs automatically."
  echo "Set WEB_IP, BASTION_IP, DB_IP, KEY_FILE env vars manually and re-run."
  exit 1
fi

info "Test 1: Access Nginx webpage from the public internet"
if curl -s --max-time 8 "http://${WEB_IP}" | grep -qi "It works"; then
  pass "Web server reachable at http://${WEB_IP}"
else
  fail "Could not reach web server at http://${WEB_IP}"
fi

info "Test 2: Verify the database is INACCESSIBLE directly from the internet"
if timeout 6 bash -c "cat < /dev/null > /dev/tcp/${DB_IP}/3306" 2>/dev/null; then
  fail "Database port 3306 was reachable directly - this should NOT happen! (${DB_IP} is a private IP and shouldn't even be routable from here, which is expected/good)"
else
  pass "Database (${DB_IP}:3306) is not reachable from the public internet, as expected"
fi

info "Test 3: Connect via Bastion Host, then test DB connectivity from the Web Server"
if [[ -f "$KEY_FILE" ]]; then
  chmod 400 "$KEY_FILE" 2>/dev/null

  ssh -o StrictHostKeyChecking=no -o ConnectTimeout=8 -i "$KEY_FILE" \
    "${SSH_USER}@${BASTION_IP}" "echo bastion-ok" >/tmp/bastion_test.log 2>&1
  if grep -q "bastion-ok" /tmp/bastion_test.log; then
    pass "SSH to Bastion Host (${BASTION_IP}) succeeded"
  else
    fail "SSH to Bastion Host (${BASTION_IP}) failed - check security group / key"
  fi

  info "Test 4: Test DB connectivity FROM the Web Server (via Bastion hop)"
  ssh -o StrictHostKeyChecking=no -o ConnectTimeout=8 -i "$KEY_FILE" \
    -J "${SSH_USER}@${BASTION_IP}" "${SSH_USER}@${WEB_IP}" \
    "timeout 5 bash -c 'cat < /dev/null > /dev/tcp/${DB_IP}/3306' && echo db-reachable-from-web" \
    >/tmp/web_to_db_test.log 2>&1
  if grep -q "db-reachable-from-web" /tmp/web_to_db_test.log; then
    pass "Database (${DB_IP}:3306) IS reachable from the Web Server, as expected"
  else
    fail "Database not reachable from Web Server - check DB security group rules"
  fi
else
  echo "  ⚠️  Key file $KEY_FILE not found - skipping SSH-based tests 3 & 4."
  echo "     Set KEY_FILE=/path/to/your/key.pem and re-run."
fi

echo -e "\nDone."
