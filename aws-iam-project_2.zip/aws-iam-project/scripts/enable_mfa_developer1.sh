#!/bin/bash
# -----------------------------------------------------------------------------
# enable_mfa_developer1.sh
#
# Finishes MFA activation for developer1 after `terraform apply` has created
# the virtual MFA device (terraform/mfa.tf). AWS requires two consecutive,
# real TOTP codes to enable a virtual MFA device - this cannot be done with
# a single static Terraform apply.
#
# If `oathtool` is installed, this script computes both codes automatically
# from the secret and finishes activation for you. Otherwise it prints
# manual instructions (e.g. for Google Authenticator / Authy).
# -----------------------------------------------------------------------------
set -euo pipefail

TF_DIR="$(dirname "$0")/../terraform"
USER_NAME="developer1"

SERIAL=$(terraform -chdir="$TF_DIR" output -raw developer1_mfa_serial_arn)
SEED=$(terraform -chdir="$TF_DIR" output -raw developer1_mfa_base32_seed)

echo "MFA device serial: $SERIAL"

if command -v oathtool >/dev/null 2>&1; then
  echo "oathtool found - computing codes automatically..."
  CODE1=$(oathtool --totp -b "$SEED")
  echo "Waiting 30s for the next TOTP window..."
  sleep 31
  CODE2=$(oathtool --totp -b "$SEED")

  aws iam enable-mfa-device \
    --user-name "$USER_NAME" \
    --serial-number "$SERIAL" \
    --authentication-code1 "$CODE1" \
    --authentication-code2 "$CODE2"

  echo "✅ MFA enabled for $USER_NAME."
else
  cat <<EOF

'oathtool' not found - finish this manually (takes ~2 minutes):

1. Convert the secret below into a QR code, or type it into your
   authenticator app (Google Authenticator, Authy, etc.) manually:

     Secret (base32): $SEED

2. Wait for the app to show a 6-digit code. Note it as CODE1.
3. Wait for the NEXT 6-digit code (after it refreshes). Note it as CODE2.
4. Run:

     aws iam enable-mfa-device \\
       --user-name $USER_NAME \\
       --serial-number $SERIAL \\
       --authentication-code1 <CODE1> \\
       --authentication-code2 <CODE2>

(Tip: install oathtool - 'sudo apt install oathtool' - to let this script
do steps 2-4 automatically next time.)
EOF
fi
