#!/bin/bash
# -----------------------------------------------------------------------------
# validate_permissions.sh
#
# Reproduces the project's Permission Validation table using the AWS CLI,
# authenticating as each IAM user with the access keys Terraform created:
#
#   developer1  Upload object            -> expect SUCCESS
#   developer1  Delete bucket            -> expect ACCESS DENIED
#   auditor1    Create EC2               -> expect ACCESS DENIED
#   devops1     Terminate EC2            -> expect SUCCESS (launches its own
#                                            throwaway instance first, so it
#                                            never touches the shared demo box)
# -----------------------------------------------------------------------------
set -uo pipefail

TF_DIR="$(dirname "$0")/../terraform"
REGION=$(terraform -chdir="$TF_DIR" output -raw aws_region 2>/dev/null || echo "us-east-1")
BUCKET=$(terraform -chdir="$TF_DIR" output -raw bucket_name)

AK_JSON=$(terraform -chdir="$TF_DIR" output -json user_access_keys)
SK_JSON=$(terraform -chdir="$TF_DIR" output -json user_secret_keys)

get_ak() { echo "$AK_JSON" | python3 -c "import json,sys; print(json.load(sys.stdin)['$1'])"; }
get_sk() { echo "$SK_JSON" | python3 -c "import json,sys; print(json.load(sys.stdin)['$1'])"; }

setup_profile() {
  local user="$1"
  aws configure set aws_access_key_id "$(get_ak "$user")" --profile "$user"
  aws configure set aws_secret_access_key "$(get_sk "$user")" --profile "$user"
  aws configure set region "$REGION" --profile "$user"
}

pass() { echo "  ✅ PASS (expected SUCCESS, got SUCCESS): $1"; }
pass_denied() { echo "  ✅ PASS (expected ACCESS DENIED, got ACCESS DENIED): $1"; }
fail() { echo "  ❌ FAIL: $1"; }

echo "Setting up temporary AWS CLI profiles for test users..."
for u in developer1 auditor1 devops1; do
  setup_profile "$u"
done
echo "(Waiting 10s for IAM credential propagation...)"
sleep 10

# --- Test 1: developer1 uploads an object -> should SUCCEED -----------------
echo -e "\n== Test 1: developer1 uploads an object to $BUCKET =="
echo "test upload $(date)" > /tmp/dev1_test_upload.txt
if aws s3 cp /tmp/dev1_test_upload.txt "s3://${BUCKET}/dev1_test_upload.txt" \
    --profile developer1 --region "$REGION" >/tmp/t1.log 2>&1; then
  pass "developer1 PutObject succeeded"
else
  fail "developer1 PutObject failed (unexpected) - see /tmp/t1.log"
  cat /tmp/t1.log
fi

# --- Test 2: developer1 tries to delete the bucket -> should be DENIED ------
echo -e "\n== Test 2: developer1 attempts to delete bucket $BUCKET =="
if aws s3api delete-bucket --bucket "$BUCKET" --profile developer1 --region "$REGION" \
    >/tmp/t2.log 2>&1; then
  fail "developer1 was able to delete the bucket - THIS IS A SECURITY ISSUE, check the policy!"
else
  if grep -qi "AccessDenied\|Forbidden" /tmp/t2.log; then
    pass_denied "developer1 DeleteBucket correctly denied"
  else
    fail "developer1 DeleteBucket failed for an unexpected reason - see /tmp/t2.log"
    cat /tmp/t2.log
  fi
fi

# --- Test 3: auditor1 tries to create an EC2 instance -> should be DENIED --
echo -e "\n== Test 3: auditor1 attempts to launch an EC2 instance =="
AMI_ID=$(aws ec2 describe-images --owners amazon \
  --filters "Name=name,Values=al2023-ami-*-x86_64" "Name=state,Values=available" \
  --query "sort_by(Images,&CreationDate)[-1].ImageId" --output text \
  --region "$REGION")

if aws ec2 run-instances --image-id "$AMI_ID" --instance-type t2.micro \
    --profile auditor1 --region "$REGION" >/tmp/t3.log 2>&1; then
  fail "auditor1 was able to launch an EC2 instance - THIS IS A SECURITY ISSUE, check ReadOnlyAccess scope!"
  # Clean up if this unexpectedly succeeded
  IID=$(python3 -c "import json;print(json.load(open('/tmp/t3.log'))['Instances'][0]['InstanceId'])" 2>/dev/null || true)
  [[ -n "$IID" ]] && aws ec2 terminate-instances --instance-ids "$IID" --profile auditor1 --region "$REGION" >/dev/null 2>&1
else
  if grep -qi "UnauthorizedOperation\|AccessDenied\|not authorized" /tmp/t3.log; then
    pass_denied "auditor1 RunInstances correctly denied"
  else
    fail "auditor1 RunInstances failed for an unexpected reason - see /tmp/t3.log"
    cat /tmp/t3.log
  fi
fi

# --- Test 4: devops1 launches then terminates its own EC2 instance --------
echo -e "\n== Test 4: devops1 launches a throwaway instance, then terminates it =="
LAUNCH_OUT=$(aws ec2 run-instances --image-id "$AMI_ID" --instance-type t2.micro \
  --profile devops1 --region "$REGION" 2>/tmp/t4_launch.log)
LAUNCH_STATUS=$?

if [[ $LAUNCH_STATUS -ne 0 ]]; then
  fail "devops1 could not even launch a test instance to terminate - see /tmp/t4_launch.log"
else
  IID=$(echo "$LAUNCH_OUT" | python3 -c "import json,sys; print(json.load(sys.stdin)['Instances'][0]['InstanceId'])")
  echo "  Launched $IID as devops1, waiting a few seconds before terminating..."
  sleep 5
  if aws ec2 terminate-instances --instance-ids "$IID" --profile devops1 --region "$REGION" \
      >/tmp/t4_terminate.log 2>&1; then
    pass "devops1 TerminateInstances succeeded on $IID"
  else
    fail "devops1 TerminateInstances failed (unexpected) - see /tmp/t4_terminate.log"
    cat /tmp/t4_terminate.log
  fi
fi

echo -e "\nDone. Full logs are in /tmp/t1.log, /tmp/t2.log, /tmp/t3.log, /tmp/t4_launch.log, /tmp/t4_terminate.log"
