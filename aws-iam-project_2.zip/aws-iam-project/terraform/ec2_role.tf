# -----------------------------------------------------------------------------
# TASK: Create an IAM role "EC2-S3-Access-Role" for EC2 with
# AmazonS3ReadOnlyAccess and attach it to an EC2 instance.
# -----------------------------------------------------------------------------

data "aws_iam_policy_document" "ec2_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "ec2_s3_access_role" {
  name               = "EC2-S3-Access-Role"
  description        = "Allows an EC2 instance to read from S3 buckets. Best practice: role-based access instead of long-lived access keys stored on the instance."
  assume_role_policy = data.aws_iam_policy_document.ec2_trust.json
}

resource "aws_iam_role_policy_attachment" "ec2_s3_readonly" {
  role       = aws_iam_role.ec2_s3_access_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess"
}

resource "aws_iam_instance_profile" "ec2_s3_access_profile" {
  name = "EC2-S3-Access-Role-Profile"
  role = aws_iam_role.ec2_s3_access_role.name
}

# --- Demo EC2 instance with the role attached ---------------------------------
# Uses the account's default VPC/subnet so this project works standalone,
# without depending on the separate "Secure AWS Network" project.
data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

data "aws_vpc" "default" {
  default = true
}

data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
}

resource "aws_security_group" "demo_ec2_sg" {
  count       = var.create_ec2_instance ? 1 : 0
  name        = "${var.project_name}-iam-demo-ec2-sg"
  description = "Minimal SG for the IAM demo EC2 instance (no inbound rules by default)"
  vpc_id      = data.aws_vpc.default.id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.project_name}-iam-demo-ec2-sg"
  }
}

resource "aws_instance" "iam_demo" {
  count                = var.create_ec2_instance ? 1 : 0
  ami                  = data.aws_ami.amazon_linux.id
  instance_type        = var.instance_type
  subnet_id            = data.aws_subnets.default.ids[0]
  vpc_security_group_ids = [aws_security_group.demo_ec2_sg[0].id]
  iam_instance_profile = aws_iam_instance_profile.ec2_s3_access_profile.name

  tags = {
    Name = "${var.project_name}-iam-demo-instance"
  }
}
