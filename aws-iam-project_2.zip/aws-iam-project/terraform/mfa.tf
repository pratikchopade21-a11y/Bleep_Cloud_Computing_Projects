# -----------------------------------------------------------------------------
# TASK: Enable MFA for developer1
#
# Terraform can PROVISION a virtual MFA device (generate the secret/QR seed),
# but "enabling" it requires two consecutive, real-time TOTP codes - by
# design, AWS won't let this be a fully static/declarative operation, since
# that would defeat the purpose of MFA. This resource creates the device;
# the final activation step is either:
#   (a) done once, manually, in 2 minutes (see docs/mfa_and_password_reset.md), or
#   (b) automated with scripts/enable_mfa_developer1.sh if you have `oathtool`
#       installed locally (it computes the two codes for you and calls the
#       AWS CLI to finish activation).
# -----------------------------------------------------------------------------

resource "aws_iam_virtual_mfa_device" "developer1" {
  virtual_mfa_device_name = "developer1-mfa"
}

# -----------------------------------------------------------------------------
# TASK: Force password reset for developer2
# (aws_iam_user_login_profile.password_reset_required is already set to true
#  for every user in users.tf, which satisfies this for developer2. Every
#  other user gets the same best-practice treatment.)
# -----------------------------------------------------------------------------
