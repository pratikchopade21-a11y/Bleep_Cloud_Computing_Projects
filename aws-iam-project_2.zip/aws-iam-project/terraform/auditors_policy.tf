# -----------------------------------------------------------------------------
# TASK: Attach AWS managed ReadOnlyAccess policy to the Auditors group
# -----------------------------------------------------------------------------

data "aws_iam_policy" "read_only_access" {
  arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

resource "aws_iam_group_policy_attachment" "auditors" {
  group      = aws_iam_group.auditors.name
  policy_arn = data.aws_iam_policy.read_only_access.arn
}
