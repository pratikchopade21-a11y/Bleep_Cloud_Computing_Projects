# -----------------------------------------------------------------------------
# TASK: Create S3 bucket "company-project-storage" and upload sample files
# -----------------------------------------------------------------------------

resource "aws_s3_bucket" "project_storage" {
  bucket = var.bucket_name

  tags = {
    Project = var.project_name
  }
}

resource "aws_s3_bucket_versioning" "project_storage" {
  bucket = aws_s3_bucket.project_storage.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_public_access_block" "project_storage" {
  bucket                  = aws_s3_bucket.project_storage.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "project_storage" {
  bucket = aws_s3_bucket.project_storage.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# Sample files uploaded on creation, per the project spec
resource "aws_s3_object" "welcome" {
  bucket = aws_s3_bucket.project_storage.id
  key    = "welcome.txt"
  source = "${path.module}/../sample-files/welcome.txt"
  etag   = filemd5("${path.module}/../sample-files/welcome.txt")
}

resource "aws_s3_object" "project_notes" {
  bucket = aws_s3_bucket.project_storage.id
  key    = "project-notes.txt"
  source = "${path.module}/../sample-files/project-notes.txt"
  etag   = filemd5("${path.module}/../sample-files/project-notes.txt")
}
