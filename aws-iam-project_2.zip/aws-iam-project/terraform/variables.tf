variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Prefix used to tag resources"
  type        = string
  default     = "abc-tech"
}

variable "bucket_name" {
  description = "Name of the S3 bucket for project storage"
  type        = string
  default     = "company-project-storage"
}

variable "developer_users" {
  description = "IAM usernames for the Developers group"
  type        = list(string)
  default     = ["developer1", "developer2"]
}

variable "devops_users" {
  description = "IAM usernames for the DevOps group"
  type        = list(string)
  default     = ["devops1", "devops2"]
}

variable "auditor_users" {
  description = "IAM usernames for the Auditors group"
  type        = list(string)
  default     = ["auditor1", "auditor2"]
}

variable "instance_type" {
  description = "EC2 instance type for the demo instance carrying EC2-S3-Access-Role"
  type        = string
  default     = "t2.micro"
}

variable "create_ec2_instance" {
  description = "Whether to actually launch the demo EC2 instance (set false to only create the role/profile)"
  type        = bool
  default     = true
}
