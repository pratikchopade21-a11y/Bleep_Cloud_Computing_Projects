# -----------------------------------------------------------------------------
# TASK: Create IAM groups (Developers, DevOps, Auditors) and assign users
# -----------------------------------------------------------------------------

resource "aws_iam_group" "developers" {
  name = "Developers"
}

resource "aws_iam_group" "devops" {
  name = "DevOps"
}

resource "aws_iam_group" "auditors" {
  name = "Auditors"
}

resource "aws_iam_group_membership" "developers" {
  name  = "developers-membership"
  group = aws_iam_group.developers.name
  users = [for u in var.developer_users : aws_iam_user.this[u].name]
}

resource "aws_iam_group_membership" "devops" {
  name  = "devops-membership"
  group = aws_iam_group.devops.name
  users = [for u in var.devops_users : aws_iam_user.this[u].name]
}

resource "aws_iam_group_membership" "auditors" {
  name  = "auditors-membership"
  group = aws_iam_group.auditors.name
  users = [for u in var.auditor_users : aws_iam_user.this[u].name]
}
