# -----------------------------------------------------------------------------
# TASK: Create a custom "Developers" policy (ListBucket, GetObject, PutObject)
# and attach it to the Developers group (least privilege: no Delete*, no
# access to any bucket other than company-project-storage).
# -----------------------------------------------------------------------------

resource "aws_iam_policy" "developers_s3_policy" {
  name        = "DevelopersS3Policy"
  description = "Allows Developers to List/Get/Put objects in company-project-storage only. No delete permissions (least privilege)."
  policy = templatefile("${path.module}/policies/developers_policy.json", {
    bucket_name = var.bucket_name
  })
}

resource "aws_iam_group_policy_attachment" "developers_s3" {
  group      = aws_iam_group.developers.name
  policy_arn = aws_iam_policy.developers_s3_policy.arn
}
