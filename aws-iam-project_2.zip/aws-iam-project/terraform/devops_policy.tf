# -----------------------------------------------------------------------------
# TASK: Create a custom "DevOps" policy (EC2 lifecycle, CloudWatch access,
# read-only VPC/IAM role visibility) and attach it to the DevOps group.
# -----------------------------------------------------------------------------

resource "aws_iam_policy" "devops_policy" {
  name        = "DevOpsOperationsPolicy"
  description = "Allows DevOps to manage the EC2 lifecycle, view CloudWatch metrics/logs, and view (not modify) VPC and IAM role configuration."
  policy      = file("${path.module}/policies/devops_policy.json")
}

resource "aws_iam_group_policy_attachment" "devops" {
  group      = aws_iam_group.devops.name
  policy_arn = aws_iam_policy.devops_policy.arn
}
