# -----------------------------------------------------------------------------
# TASK: Create 6 IAM users
# -----------------------------------------------------------------------------
locals {
  all_users = concat(var.developer_users, var.devops_users, var.auditor_users)
}

resource "aws_iam_user" "this" {
  for_each = toset(local.all_users)
  name     = each.value
  tags = {
    Project = var.project_name
  }
}

# Random console passwords for every user (satisfies "force password reset"
# for developer2 by requiring reset on first login; other users get one too
# so they can be tested via console if desired).
resource "random_password" "console" {
  for_each         = toset(local.all_users)
  length           = 16
  special          = true
  override_special = "!@#%^&*()-_=+"
}

resource "aws_iam_user_login_profile" "this" {
  for_each                = toset(local.all_users)
  user                    = aws_iam_user.this[each.value].name
  password_reset_required = true # every user must set their own password on first login
  password_length         = 16
}

# -----------------------------------------------------------------------------
# Programmatic (CLI) access keys - used by scripts/validate_permissions.sh to
# actually exercise each user's real permissions with the AWS CLI.
#
# NOTE (best practice callout): in a real environment, prefer IAM Identity
# Center / SSO or roles over long-lived access keys for humans. Keys are
# created here purely so this project's permission tests are fully automatable.
# -----------------------------------------------------------------------------
resource "aws_iam_access_key" "this" {
  for_each = toset(local.all_users)
  user     = aws_iam_user.this[each.value].name
}
