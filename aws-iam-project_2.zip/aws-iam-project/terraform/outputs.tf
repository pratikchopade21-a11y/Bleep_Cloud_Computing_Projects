output "aws_region" {
  value = var.aws_region
}

output "developers_group_arn" {
  value = aws_iam_group.developers.arn
}

output "devops_group_arn" {
  value = aws_iam_group.devops.arn
}

output "auditors_group_arn" {
  value = aws_iam_group.auditors.arn
}

output "bucket_name" {
  value = aws_s3_bucket.project_storage.bucket
}

output "ec2_role_arn" {
  value = aws_iam_role.ec2_s3_access_role.arn
}

output "ec2_instance_id" {
  value = var.create_ec2_instance ? aws_instance.iam_demo[0].id : "not created (create_ec2_instance = false)"
}

output "developer1_mfa_serial_arn" {
  description = "ARN of developer1's virtual MFA device (needed to finish activation)"
  value       = aws_iam_virtual_mfa_device.developer1.arn
}

output "developer1_mfa_base32_seed" {
  description = "Base32 TOTP secret for developer1's authenticator app - treat as a secret"
  value       = aws_iam_virtual_mfa_device.developer1.base32_string_seed
  sensitive   = true
}

output "user_console_passwords" {
  description = "Initial console passwords for all 6 users (each must reset on first login)"
  value       = { for u in local.all_users : u => aws_iam_user_login_profile.this[u].password }
  sensitive   = true
}

output "user_access_keys" {
  description = "Programmatic access key IDs for all 6 users (used by validate_permissions.sh)"
  value       = { for u in local.all_users : u => aws_iam_access_key.this[u].id }
}

output "user_secret_keys" {
  description = "Programmatic secret access keys for all 6 users"
  value       = { for u in local.all_users : u => aws_iam_access_key.this[u].secret }
  sensitive   = true
}
