# AWS IAM – Roles, Policies & Permission Best Practices

## Project Objective
Learn IAM users, groups, roles, custom policies, least privilege, MFA, and
permission validation — deployed automatically with Terraform.

## Scenario
ABC Technologies has migrated to AWS. This project implements secure IAM
access for **Developers**, **DevOps Engineers**, and **Auditors** using AWS
IAM best practices.

## Architecture
```
AWS Account
│
├── Developers Group  → Custom S3 Policy (List/Get/Put)      → developer1, developer2
│
├── DevOps Group      → EC2/CloudWatch/Read-only IAM policy   → devops1, devops2
│
├── Auditors Group    → AWS Managed ReadOnlyAccess             → auditor1, auditor2
│
└── EC2 IAM Role (EC2-S3-Access-Role) → AmazonS3ReadOnlyAccess → attached to an EC2 instance
```

## Repository Layout
```
aws-iam-project/
├── README.md
├── terraform/
│   ├── provider.tf
│   ├── variables.tf
│   ├── users.tf                  <- 6 IAM users + login profiles
│   ├── groups.tf                 <- 3 groups + memberships
│   ├── policies/
│   │   ├── developers_policy.json
│   │   └── devops_policy.json
│   ├── developers_policy.tf      <- custom S3 policy, attached to Developers group
│   ├── devops_policy.tf          <- custom EC2/CloudWatch/IAM-readonly policy
│   ├── auditors_policy.tf        <- attaches AWS managed ReadOnlyAccess
│   ├── s3_bucket.tf              <- company-project-storage + sample file uploads
│   ├── ec2_role.tf               <- EC2-S3-Access-Role + instance profile + EC2 instance
│   ├── mfa.tf                    <- virtual MFA device for developer1, forced reset for developer2
│   └── outputs.tf
├── sample-files/                 <- files uploaded to the S3 bucket
│   ├── welcome.txt
│   └── project-notes.txt
├── scripts/
│   └── validate_permissions.sh   <- runs the 4-row permission test table automatically
└── docs/
    ├── implementation_steps.md
    ├── policies_explained.md
    ├── mfa_and_password_reset.md
    └── learning_outcomes.md
```

## Prerequisites
1. AWS account with an admin IAM user (never use the root account for this).
2. [Terraform](https://developer.hashicorp.com/terraform/install) >= 1.5.
3. [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html) v2, configured (`aws configure`) with your admin credentials.
4. `jq` (optional, used by the validation script for readable output).

## Quick Start

```bash
cd terraform
terraform init
terraform plan
terraform apply
```

Type `yes` when prompted. Terraform will create, in order:
1. 6 IAM users (developer1, developer2, devops1, devops2, auditor1, auditor2)
2. 3 IAM groups (Developers, DevOps, Auditors) with the users assigned
3. The S3 bucket `company-project-storage` with 2 sample files uploaded
4. A custom Developers policy (ListBucket, GetObject, PutObject on the bucket) attached to the Developers group
5. A custom DevOps policy (EC2 lifecycle, CloudWatch, read-only VPC/IAM visibility) attached to the DevOps group
6. The AWS-managed `ReadOnlyAccess` policy attached to the Auditors group
7. The `EC2-S3-Access-Role` IAM role (trust = EC2) with `AmazonS3ReadOnlyAccess` attached, wrapped in an instance profile
8. A small EC2 instance with that instance profile attached
9. A virtual MFA device provisioned for `developer1` (activation is a manual, one-time step — see `docs/mfa_and_password_reset.md`)
10. A console login profile for `developer2` with `password_reset_required = true`

Terraform will print each user's **console login password** and **access
keys** once, in the `terraform apply` output / `terraform output` — treat
this like any other secret.

## Permission Validation
Run the automated test script after `terraform apply` finishes:

```bash
cd ../scripts
chmod +x validate_permissions.sh
./validate_permissions.sh
```

It reproduces the table from the spec:

| User | Action | Expected Result |
|---|---|---|
| developer1 | Upload object to `company-project-storage` | ✅ Success |
| developer1 | Delete the bucket | ❌ Access Denied |
| auditor1 | Create an EC2 instance | ❌ Access Denied |
| devops1 | Terminate an EC2 instance | ✅ Success |

## Deliverables Checklist
This project produces every deliverable the spec asks for:
- [x] IAM Users — `terraform/users.tf`
- [x] IAM Groups — `terraform/groups.tf`
- [x] Custom Policies — `terraform/developers_policy.tf`, `terraform/devops_policy.tf`
- [x] IAM Role — `terraform/ec2_role.tf`
- [x] S3 Bucket — `terraform/s3_bucket.tf`
- [x] EC2 with attached IAM Role — `terraform/ec2_role.tf`
- [x] MFA enabled (device provisioned; activation documented) — `terraform/mfa.tf`, `docs/mfa_and_password_reset.md`
- [x] Permission test results — `scripts/validate_permissions.sh`
- [x] Project documentation with learning outcomes — `docs/learning_outcomes.md`

Take screenshots of the AWS Console (IAM → Users/Groups/Policies/Roles, S3,
EC2) after `apply` finishes to satisfy the "Screenshot of..." deliverables —
Terraform can't produce console screenshots for you, but every resource
listed will exist and be visible there.

## Tearing Down
```bash
cd terraform
terraform destroy
```

## IAM Best Practices Applied in This Project
- MFA enabled for a user (developer1)
- IAM groups used instead of attaching permissions directly to users
- Least privilege: Developers get only S3 List/Get/Put on one bucket; Auditors get read-only; DevOps gets scoped EC2/CloudWatch/read-only IAM/VPC
- Root account is never used or referenced
- EC2 uses an IAM **role** (`EC2-S3-Access-Role`), not long-lived access keys, to reach S3
- `password_reset_required` forces credential rotation for developer2
- CloudTrail monitoring guidance included in `docs/learning_outcomes.md`
- Unused/least-privilege policies mean nothing is over-provisioned by default
