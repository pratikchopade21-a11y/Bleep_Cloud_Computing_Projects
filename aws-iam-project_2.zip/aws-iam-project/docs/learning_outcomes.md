# Learning Outcomes & IAM Best Practices Reference

## What This Project Demonstrates
- **IAM Users** — individual identities for each person (never shared logins).
- **IAM Groups** — permissions attached to *groups* (Developers, DevOps,
  Auditors), not to individual users, so onboarding/offboarding is just a
  group-membership change.
- **Custom Policies** — least-privilege, hand-written JSON policies scoped
  to exactly the actions and resources each role needs (see
  `docs/policies_explained.md`).
- **AWS Managed Policies** — using `ReadOnlyAccess` and
  `AmazonS3ReadOnlyAccess` where an AWS-curated policy already fits, instead
  of reinventing it.
- **IAM Roles** — `EC2-S3-Access-Role` lets an EC2 instance access S3
  without any access keys stored on the box; AWS rotates the temporary
  credentials automatically behind the scenes.
- **MFA** — an extra authentication factor beyond password, enabled for
  developer1.
- **Forced credential rotation** — `password_reset_required` for developer2
  (and, as a bonus best practice, for every user in this project).
- **Permission validation** — proving policies work as intended by actually
  attempting the allowed and disallowed actions, not just reading the JSON
  and assuming it's correct.

## IAM Best Practices Checklist (from the spec, applied here)
| Practice | Where it's applied |
|---|---|
| Enable MFA | `terraform/mfa.tf` — developer1 |
| Use groups, not per-user permissions | `terraform/groups.tf`, `developers_policy.tf`, `devops_policy.tf`, `auditors_policy.tf` — policies attach to groups only |
| Apply least privilege | Developers get only List/Get/Put on one bucket; DevOps gets scoped EC2/CloudWatch/read-only IAM+VPC; Auditors get read-only |
| Avoid root account usage | Everything here runs under an admin IAM user/role, never root |
| Use IAM roles instead of long-term access keys (for AWS resources) | `EC2-S3-Access-Role` — the EC2 instance never stores an access key |
| Rotate credentials regularly | `password_reset_required = true` forces a fresh password on first login |
| Monitor IAM with CloudTrail | See "CloudTrail" section below |
| Remove unused users and permissions | Run `terraform destroy` when the exercise is done; in production, periodically audit with IAM Access Analyzer / the IAM console's "last used" data |

## Adding CloudTrail Monitoring (optional extension)
This project focuses on IAM itself, but a natural next step is enabling
AWS CloudTrail to log every IAM/S3/EC2 API call made by these users, so you
can audit who did what and when:
```hcl
resource "aws_cloudtrail" "main" {
  name                          = "abc-tech-iam-audit-trail"
  s3_bucket_name                = aws_s3_bucket.cloudtrail_logs.id
  include_global_service_events = true
  is_multi_region_trail         = true
}
```
(Not included by default here to keep this project focused and inexpensive
to run for learning purposes — add it if you want to extend the exercise.)

## Suggested Next Steps
1. Enable AWS IAM Access Analyzer to catch overly-permissive policies.
2. Add a Service Control Policy (SCP) at the AWS Organizations level to
   prevent root account usage account-wide.
3. Replace the long-lived access keys created here (for automated testing)
   with IAM Identity Center / temporary STS credentials for any real human
   users going forward.
4. Add tag-based conditions to the DevOps EC2 policy so it only controls
   instances tagged for their team, rather than every instance in the account.
