# MFA (developer1) and Forced Password Reset (developer2)

## Why MFA activation can't be 100% one-shot Terraform
AWS deliberately requires **two consecutive, real-time TOTP codes** to
activate a virtual MFA device (`enable-mfa-device`). This proves a human (or
an authenticator) actually holds the live secret — a single `terraform
apply` can create the *device* (the secret/QR seed) but the activation step
needs those two live codes, generated 30 seconds apart.

## Option A: Manual activation (2 minutes, recommended for a learning project)
1. `terraform apply` creates the virtual MFA device for developer1.
2. Get the secret: `terraform -chdir=terraform output -raw developer1_mfa_base32_seed`
3. Enter that secret manually into Google Authenticator / Authy / 1Password
   (choose "enter a setup key" instead of scanning a QR code), or generate a
   QR code from the secret using any offline QR generator.
4. Note the current 6-digit code (CODE1). Wait ~30s for it to refresh, note
   the new code (CODE2).
5. Run:
   ```bash
   aws iam enable-mfa-device \
     --user-name developer1 \
     --serial-number "$(terraform -chdir=terraform output -raw developer1_mfa_serial_arn)" \
     --authentication-code1 <CODE1> \
     --authentication-code2 <CODE2>
   ```
6. Verify: `aws iam list-mfa-devices --user-name developer1` should now show
   the device as associated. Take your screenshot here for the deliverable.

## Option B: Scripted activation with `oathtool`
If you have `oathtool` installed (`sudo apt install oathtool` /
`brew install oath-toolkit`), run:
```bash
cd scripts
chmod +x enable_mfa_developer1.sh
./enable_mfa_developer1.sh
```
This computes both TOTP codes from the secret automatically and calls
`enable-mfa-device` for you — useful for CI/CD or fully hands-off demos, but
in production you'd normally want a real human enrolling their own device.

## Forced Password Reset for developer2
Already handled declaratively in `terraform/users.tf`:
```hcl
resource "aws_iam_user_login_profile" "this" {
  for_each                = toset(local.all_users)
  user                    = aws_iam_user.this[each.value].name
  password_reset_required = true
  password_length         = 16
}
```
Every user (including developer2) is created with `password_reset_required =
true`, meaning the very first console sign-in forces them to set their own
new password before proceeding — nobody, including the admin who ran
Terraform, retains long-term knowledge of the real password they'll use.
