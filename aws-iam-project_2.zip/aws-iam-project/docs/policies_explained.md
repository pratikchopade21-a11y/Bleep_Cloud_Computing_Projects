# Policies Explained

## DevelopersS3Policy (custom, attached to the Developers group)
```json
{
  "Version": "2012-10-17",
  "Statement": [
    { "Sid": "ListBucketOnly", "Effect": "Allow",
      "Action": ["s3:ListBucket"],
      "Resource": "arn:aws:s3:::company-project-storage" },
    { "Sid": "GetAndPutObjects", "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject"],
      "Resource": "arn:aws:s3:::company-project-storage/*" }
  ]
}
```
**Why no `DeleteObject` or `DeleteBucket`?** This is the least-privilege
principle in action: developers need to read and write project files, but
destructive bucket-level operations aren't part of their job, so the policy
simply never grants them — matching the spec's expected "Access Denied" for
`developer1 → Delete bucket`.

**Why is the Resource scoped to `company-project-storage` specifically?**
Without this, an overly broad `"Resource": "*"` would let developers touch
*every* bucket in the account. Scoping to the ARN of one bucket is a
textbook least-privilege pattern.

## DevOpsOperationsPolicy (custom, attached to the DevOps group)
Grants three categories of access, all resource-unscoped (`*`) because EC2
instance IDs are dynamic, but you could tighten this further in production
with tag-based conditions (e.g. only instances tagged `Team=DevOps`):
1. **EC2 lifecycle**: `RunInstances`, `StartInstances`, `StopInstances`,
   `RebootInstances`, `TerminateInstances`, plus the `Describe*` calls
   needed to actually use the console/CLI.
2. **CloudWatch access**: metrics, alarms, and log-group visibility for
   monitoring the infrastructure they manage.
3. **Read-only VPC/IAM role visibility**: `Describe*` calls for VPCs, route
   tables, IGWs, NAT gateways, and `Get*`/`List*` calls for IAM roles —
   DevOps can *see* how networking and roles are configured (useful for
   troubleshooting) but cannot create, modify, or delete them.

**Why can DevOps terminate EC2 instances but not create/delete IAM users or
policies?** Separation of duties: DevOps manages compute, not identity.
That boundary is what makes `devops1 → Terminate EC2 → Success` correct
while `devops1` still can't touch IAM.

## ReadOnlyAccess (AWS managed, attached to the Auditors group)
A broad, AWS-maintained read-only policy covering most services (`Describe*`,
`List*`, `Get*` across EC2, S3, IAM, CloudWatch, etc.) with **zero** write or
delete actions anywhere. This is why `auditor1 → Create EC2 → Access Denied`
— `ec2:RunInstances` is a write action and is never included in
`ReadOnlyAccess`.

## AmazonS3ReadOnlyAccess (AWS managed, attached to EC2-S3-Access-Role)
Lets the EC2 instance itself read from S3 buckets (e.g. to pull config files
or datasets) without needing any access keys stored on the instance —
credentials are delivered automatically and rotated by AWS via the instance
metadata service when a role is attached this way.
