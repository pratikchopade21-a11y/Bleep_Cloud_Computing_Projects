# Implementation Steps (Manual / AWS Console Reference)

The Terraform code in `terraform/` automates every step below. Use this if
you need to demonstrate the manual console process, or want to understand
exactly what's being created.

## 1. Create 6 IAM Users
IAM → Users → Create user, for each of: `developer1`, `developer2`,
`devops1`, `devops2`, `auditor1`, `auditor2`. Enable console access, set
"User must create a new password at next sign-in" for all (required for
developer2 per the spec; recommended for everyone).

## 2. Create IAM Groups
IAM → User groups → Create group: `Developers`, `DevOps`, `Auditors`.
Add `developer1`/`developer2` to Developers, `devops1`/`devops2` to DevOps,
`auditor1`/`auditor2` to Auditors.

## 3. Create S3 Bucket
S3 → Create bucket → name it exactly `company-project-storage` (must be
globally unique — if taken, Terraform will fail with a clear error and you
should change `bucket_name` in `terraform.tfvars`). Upload `welcome.txt` and
`project-notes.txt` from `sample-files/`.

## 4. Create the Developers Custom Policy
IAM → Policies → Create policy → JSON tab → paste
`terraform/policies/developers_policy.json` (replace `${bucket_name}` with
`company-project-storage`). Name it `DevelopersS3Policy`. Attach it to the
**Developers** group (never attach policies directly to users).

## 5. Create the DevOps Custom Policy
Same process using `terraform/policies/devops_policy.json`, named
`DevOpsOperationsPolicy`. Attach to the **DevOps** group.

## 6. Attach ReadOnlyAccess to Auditors
IAM → User groups → Auditors → Permissions → Attach policies → search
`ReadOnlyAccess` (AWS managed) → Attach.

## 7. Create the EC2 IAM Role
IAM → Roles → Create role → Trusted entity: **AWS service** → **EC2** →
attach `AmazonS3ReadOnlyAccess` → name it `EC2-S3-Access-Role`.

## 8. Attach the Role to an EC2 Instance
Launch (or select an existing) EC2 instance → Actions → Security → Modify
IAM role → select `EC2-S3-Access-Role`.

## 9. Enable MFA for developer1
IAM → Users → developer1 → Security credentials → Assign MFA device →
Virtual MFA device → scan the QR code with an authenticator app → enter two
consecutive codes to finish. (See `docs/mfa_and_password_reset.md` for the
scripted/CLI equivalent.)

## 10. Force Password Reset for developer2
IAM → Users → developer2 → Security credentials → if a console password
already exists, there's no single "force reset" button after creation in
the newer console; the standard approach is: Security credentials → Console
sign-in → Manage → check "User must create a new password at next sign-in".
(Terraform sets this at creation time via `password_reset_required = true`.)

## 11. Validate Permissions
Sign in as each test user (or use the AWS CLI with their access keys) and
run the four scenarios in the Permission Validation table — see
`scripts/validate_permissions.sh` for the automated version.
