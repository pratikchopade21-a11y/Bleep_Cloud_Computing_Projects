# Minor Project 4 – Docker + Jenkins/GitHub Actions Automation Project

## Objective
Build a CI/CD pipeline — using either Jenkins **or** GitHub Actions (both are
provided, ready to use) — that automatically pulls code, builds a Docker
image, scans it for vulnerabilities with Trivy, and pushes it to a container
registry.

## Tools
- Jenkins / GitHub Actions (both implementations included)
- Docker
- GitHub
- Trivy (vulnerability scanner)

## Features Implemented
1. **Pull code from GitHub** — `actions/checkout` (GitHub Actions) or
   `checkout scm` (Jenkins)
2. **Build Docker image** — multi-stage `sample-app/Dockerfile`
3. **Scan Docker image using Trivy** — fails the pipeline on any
   CRITICAL/HIGH vulnerability, so a vulnerable image can never reach the
   push step
4. **Push Docker image to the Registry** — Docker Hub by default (easy to
   repoint at GHCR/ECR/ACR — see `docs/registry_options.md`)

## Repository Layout
```
docker-cicd-project/
├── README.md
├── Jenkinsfile                        <- Jenkins pipeline (all 4 features)
├── .github/workflows/docker-ci.yml    <- GitHub Actions pipeline (all 4 features)
├── sample-app/                        <- the app being containerized
│   ├── app.js
│   ├── package.json
│   ├── test.js
│   ├── Dockerfile
│   └── .dockerignore
└── docs/
    ├── github_actions_setup.md
    ├── jenkins_setup.md
    ├── trivy_explained.md
    └── registry_options.md
```

## Pipeline Flow (both implementations)
```
GitHub push
     │
     ▼
Pull code from GitHub  ──►  Build Docker image  ──►  Scan with Trivy
                                                            │
                                             ┌──────────────┴───────────────┐
                                       Vulnerabilities found          Clean scan
                                       (CRITICAL/HIGH)                     │
                                             │                             ▼
                                        ❌ Pipeline fails           Push image to Registry
                                        (image never pushed)               │
                                                                            ▼
                                                                       ✅ Done
```

## Option A: GitHub Actions (fastest to try — no server to set up)
See `docs/github_actions_setup.md`. In short:
1. Push this repo to GitHub.
2. Add two repository secrets: `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`.
3. Push to `main` (or run the workflow manually from the Actions tab) —
   the pipeline in `.github/workflows/docker-ci.yml` runs automatically.

## Option B: Jenkins
See `docs/jenkins_setup.md`. In short:
1. Install Docker and Trivy on the Jenkins agent.
2. Create Jenkins credentials: `dockerhub-credentials` (and
   `github-credentials` if the repo is private).
3. Create a new Pipeline job pointing at this repo, using the included
   `Jenkinsfile`.
4. Edit `IMAGE_NAME` at the top of the `Jenkinsfile` to your own Docker Hub
   username/repo.

## Testing the Sample App Locally (optional, before wiring up CI)
```bash
cd sample-app
docker build -t docker-cicd-sample-app:local .
docker run -p 3000:3000 docker-cicd-sample-app:local
curl http://localhost:3000/health
```

## Trivy — Why and How
See `docs/trivy_explained.md` for what Trivy checks, how the severity
threshold works, and how to read its output.

## Learning Outcomes
- Building a real CI/CD pipeline end-to-end, in two different tools that
  solve the same problem differently (declarative YAML vs. Jenkins DSL)
- Multi-stage Docker builds for smaller, more secure images
- Shifting security left: scanning for vulnerabilities *before* an image
  ever reaches a registry or production, and using scan results to gate
  the pipeline automatically
- Managing secrets (registry credentials) safely in both GitHub Actions
  (repo secrets) and Jenkins (credentials store) instead of hardcoding them
- Registry authentication and image tagging strategy (`:latest` plus an
  immutable build-specific tag)
