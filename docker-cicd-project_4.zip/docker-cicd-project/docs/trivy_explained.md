# Trivy — What It Checks and How the Gate Works

## What is Trivy?
[Trivy](https://aquasecurity.github.io/trivy) (by Aqua Security) is an
open-source scanner that inspects a container image and reports:
- **OS package vulnerabilities** — known CVEs in packages installed by the
  base image's package manager (apk/apt/yum/etc.)
- **Application dependency vulnerabilities** — known CVEs in language-level
  packages (here: npm packages listed in `package.json`/`package-lock.json`)
- **Misconfigurations** (optional, not enabled by default in this project) —
  Dockerfile best-practice violations, e.g. running as root
- **Secrets** (optional) — accidentally baked-in API keys, passwords, etc.

## How the Pipeline Uses It
Both the Jenkins and GitHub Actions pipelines run:
```bash
trivy image --severity CRITICAL,HIGH --ignore-unfixed --exit-code 1 <image>
```
- `--severity CRITICAL,HIGH` — only these severities can fail the build;
  LOW/MEDIUM findings are still visible in the output but won't block you.
  This keeps the pipeline useful without becoming impossible to pass.
- `--ignore-unfixed` — skips vulnerabilities that don't have a fix available
  yet (there's nothing actionable you could do about those today).
- `--exit-code 1` — makes Trivy return a non-zero exit code when it finds a
  matching vulnerability, which is what actually causes the CI step/stage to
  fail and stop the pipeline before the push step runs.

## Reading Trivy's Output
```
sample-app (alpine 3.19.1)
===========================
Total: 2 (HIGH: 1, CRITICAL: 1)

┌────────────┬────────────────┬──────────┬──────────┬───────────────┬───────────────┬──────────────────────────┐
│  Library   │ Vulnerability  │ Severity │  Status  │ Installed Ver │  Fixed Ver    │           Title          │
├────────────┼────────────────┼──────────┼──────────┼───────────────┼───────────────┼──────────────────────────┤
│ libssl3    │ CVE-2024-XXXXX │ CRITICAL │ fixed    │ 3.1.4-r0      │ 3.1.5-r0      │ OpenSSL: buffer overflow │
└────────────┴────────────────┴──────────┴──────────┴───────────────┴───────────────┴──────────────────────────┘
```
- **Library** — the vulnerable package
- **Installed Ver / Fixed Ver** — upgrading to "Fixed Ver" resolves it
- **Status** — `fixed` means a patched version exists (and is what
  `--ignore-unfixed` filters on)

## Fixing a Failed Scan
1. **Base image out of date** → bump the tag in `sample-app/Dockerfile`
   (e.g. `node:20-alpine` → `node:20.15-alpine3.20`) and rebuild.
2. **Vulnerable npm package** → run `npm audit fix` in `sample-app/`, commit
   the updated `package-lock.json`, and rebuild.
3. **No fix available yet** → this is exactly what `--ignore-unfixed`
   already filters out; if it's still failing the build, a fix does exist
   and you should apply it.

## Scanning Locally Before Pushing
```bash
cd sample-app
docker build -t local-test .
trivy image --severity CRITICAL,HIGH local-test
```
Catching issues locally, before even opening a PR, is the whole point of
"shifting security left."
