# Using a Different Registry

Both pipelines default to **Docker Hub** since it's free and the fastest to
set up for a learning project. Here's how to repoint them elsewhere.

## GitHub Container Registry (GHCR) — no separate account needed
GitHub Actions only:
```yaml
env:
  IMAGE_NAME: ghcr.io/${{ github.repository_owner }}/docker-cicd-sample-app

steps:
  - name: Log in to GHCR
    uses: docker/login-action@v3
    with:
      registry: ghcr.io
      username: ${{ github.actor }}
      password: ${{ secrets.GITHUB_TOKEN }}   # provided automatically, no setup needed
```
No new secrets required — `GITHUB_TOKEN` is injected automatically by
GitHub Actions on every run.

## AWS Elastic Container Registry (ECR)
1. Create a repository: `aws ecr create-repository --repository-name docker-cicd-sample-app`
2. In GitHub Actions, use `aws-actions/amazon-ecr-login@v2` before the build
   step, and set `IMAGE_NAME` to the ECR repository URI
   (`<account-id>.dkr.ecr.<region>.amazonaws.com/docker-cicd-sample-app`).
3. In Jenkins, install the Amazon ECR plugin, or run
   `aws ecr get-login-password | docker login --username AWS --password-stdin <ecr-uri>`
   as a shell step before `docker push`.

## Azure Container Registry (ACR)
1. `az acr create --name <registryname> --resource-group <rg> --sku Basic`
2. Log in with `az acr login --name <registryname>` (Jenkins) or
   `docker/login-action@v3` with `registry: <registryname>.azurecr.io` plus
   an ACR service principal's username/password (GitHub Actions).

## Self-hosted Registry
Point `IMAGE_NAME` / the `docker login` step at your registry's hostname
(e.g. `registry.example.com/docker-cicd-sample-app`) and supply whatever
credentials your registry requires.
