# Jenkins Setup

## 1. Prerequisites on the Jenkins Agent/Controller
Install Docker and Trivy on whichever machine will actually run the
pipeline steps (the Jenkins agent):

```bash
# Docker (Ubuntu/Debian example)
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker jenkins    # let the jenkins user run docker commands
sudo systemctl restart jenkins

# Trivy (Ubuntu/Debian example)
sudo apt-get install -y wget apt-transport-https gnupg lsb-release
wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | sudo gpg --dearmor -o /usr/share/keyrings/trivy.gpg
echo "deb [signed-by=/usr/share/keyrings/trivy.gpg] https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main" | sudo tee -a /etc/apt/sources.list.d/trivy.list
sudo apt-get update
sudo apt-get install -y trivy
```
(See Trivy's official docs for other OSes: https://aquasecurity.github.io/trivy)

## 2. Install Jenkins Plugins
From **Manage Jenkins → Plugins**, make sure these are installed:
- Docker Pipeline
- Git
- Credentials Binding
- Pipeline

## 3. Create Jenkins Credentials
**Manage Jenkins → Credentials → System → Global credentials → Add
Credentials**:

| ID | Kind | Used for |
|---|---|---|
| `dockerhub-credentials` | Username with password | Docker Hub username + access token (see `docs/github_actions_setup.md` step 2 for how to generate a token) |
| `github-credentials` | Username with password (or SSH key) | Only needed if your GitHub repo is private |

## 4. Create the Pipeline Job
1. Jenkins Dashboard → **New Item** → name it, choose **Pipeline** → OK.
2. Under **Pipeline**, set Definition to **Pipeline script from SCM**.
3. SCM: **Git**, Repository URL: your GitHub repo URL, Credentials: the
   `github-credentials` entry (if private) or none (if public).
4. Script Path: `Jenkinsfile` (default — matches this project).
5. Save.

## 5. Edit the Image Name
Open the `Jenkinsfile` at the repo root and change:
```groovy
IMAGE_NAME = "yourdockerhubusername/docker-cicd-sample-app"
```
to your actual Docker Hub username.

## 6. Run It
Click **Build Now**. The console output will show all four stages in order:
Pull code from GitHub → Build Docker image → Scan Docker image using Trivy
→ Push Docker Image to the Registry.

## Troubleshooting
- **`docker: permission denied`** → the `jenkins` user isn't in the `docker`
  group yet, or Jenkins wasn't restarted after adding it (step 1).
- **`trivy: command not found`** → Trivy isn't installed on the agent Jenkins
  actually runs the build on (check you installed it on the right machine if
  you have multiple agents).
- **Pipeline fails at the Trivy stage** → this is expected/working as
  intended when vulnerabilities are found. See `docs/trivy_explained.md`.
- **Push stage fails with `unauthorized`** → double-check the
  `dockerhub-credentials` entry has a valid Docker Hub access token (not
  your account password, which Docker Hub may reject for API logins).
