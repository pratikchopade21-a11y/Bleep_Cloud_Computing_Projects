# GitHub Actions Setup

## 1. Push this project to a GitHub repository
```bash
git init
git add .
git commit -m "Initial commit - Docker CI/CD pipeline"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

## 2. Create a Docker Hub Access Token
1. Log in to [hub.docker.com](https://hub.docker.com).
2. Account Settings → Security → **New Access Token**.
3. Give it a description (e.g. `github-actions-ci`), scope: Read & Write.
4. Copy the token immediately — you won't be able to see it again.

## 3. Add Repository Secrets
In your GitHub repo: **Settings → Secrets and variables → Actions → New
repository secret**. Add:

| Secret name | Value |
|---|---|
| `DOCKERHUB_USERNAME` | Your Docker Hub username |
| `DOCKERHUB_TOKEN` | The access token from step 2 |

## 4. Update the image name (optional)
`.github/workflows/docker-ci.yml` already builds the image name from
`${{ secrets.DOCKERHUB_USERNAME }}/docker-cicd-sample-app` — you only need to
rename the repo part if you want something other than
`docker-cicd-sample-app`.

## 5. Trigger the pipeline
- Push any commit to `main`, or
- Go to the **Actions** tab → "Docker Build, Scan & Push" → **Run workflow**

## 6. Where to see results
- **Actions tab** → click the run → each step (checkout, build, Trivy scan,
  push) shows its own log.
- **Security tab → Code scanning alerts** → Trivy's SARIF results appear
  here automatically (via `github/codeql-action/upload-sarif`), giving you a
  persistent, browsable vulnerability history across builds.

## Troubleshooting
- **"denied: requested access to the resource is denied"** on push → double
  check `DOCKERHUB_USERNAME`/`DOCKERHUB_TOKEN` are correct and the token has
  Read & Write scope.
- **Trivy step fails the build** → this is expected behavior when a
  CRITICAL/HIGH vulnerability is found; see `docs/trivy_explained.md` for how
  to interpret and fix it (usually: bump the base image or an npm package).
- **Want to allow the pipeline to continue despite vulnerabilities (not
  recommended)?** Change `exit-code: '1'` to `exit-code: '0'` in the first
  Trivy step of the workflow — but this defeats the purpose of scanning.
