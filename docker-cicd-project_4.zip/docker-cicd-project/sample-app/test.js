// Minimal smoke test - starts the app, hits /health, exits non-zero on failure.
// Kept dependency-free so it runs in the CI pipeline without extra installs.
const http = require('http');
const { spawn } = require('child_process');

const PORT = 4000;
const child = spawn('node', ['app.js'], {
  env: { ...process.env, PORT: String(PORT) },
  stdio: 'inherit',
});

function fail(msg) {
  console.error(`TEST FAILED: ${msg}`);
  child.kill();
  process.exit(1);
}

setTimeout(() => {
  http
    .get(`http://localhost:${PORT}/health`, (res) => {
      if (res.statusCode === 200) {
        console.log('TEST PASSED: /health returned 200');
        child.kill();
        process.exit(0);
      } else {
        fail(`/health returned status ${res.statusCode}`);
      }
    })
    .on('error', (err) => fail(err.message));
}, 1500);

setTimeout(() => fail('timed out waiting for app to start'), 8000);
