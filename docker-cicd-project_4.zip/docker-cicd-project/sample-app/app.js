const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.json({
    message: 'Hello from the Docker + CI/CD Automation Project!',
    project: 'Minor Project 4',
    pipeline: 'GitHub -> Docker Build -> Trivy Scan -> Push to Registry',
  });
});

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

app.listen(PORT, () => {
  console.log(`App listening on port ${PORT}`);
});
