# Learning Outcomes

## What This Project Demonstrates
- **Infrastructure as Code (IaC)** — defining AWS resources declaratively in
  `.tf` files instead of clicking through the console, so the whole setup is
  version-controlled, repeatable, and destroyable in one command.
- **VPC fundamentals** — a VPC is an isolated virtual network; nothing in it
  can reach (or be reached from) the internet until you explicitly wire up
  an Internet Gateway and route table.
- **Subnets** — a logical subdivision of the VPC's IP range, tied to a
  specific Availability Zone.
- **Public vs. private reachability** — `map_public_ip_on_launch`, the
  Internet Gateway, and the route table's `0.0.0.0/0` route are the three
  pieces that together make a subnet "public." Removing any one of them
  would make the EC2 instance unreachable from the internet.
- **Security Groups** — a stateful, instance-level firewall; here scoped to
  allow SSH from a single IP rather than the world, which is a core AWS
  security best practice.
- **EC2 provisioning via Terraform** — using a `data "aws_ami"` lookup to
  always deploy the latest Amazon Linux image, rather than hardcoding an AMI
  ID that will eventually go stale.
- **SSH key management** — Terraform can generate a brand-new keypair for
  you (`tls_private_key` + `aws_key_pair`) so the project works even if you
  don't already have one, while still supporting bringing your own existing
  key pair.
- **Terraform outputs** — surfacing the values you actually need after
  `apply` (public IP, ready-made SSH command) instead of having to look them
  up manually in the console.

## Key Terraform Concepts Used
| Concept | Where |
|---|---|
| `resource` blocks | vpc.tf, subnet.tf, ec2.tf, etc. |
| `data` source | `data "aws_ami"` in ec2.tf — looks up the latest AMI dynamically |
| `variable` / `terraform.tfvars` | variables.tf — parameterizes region, CIDR, IP, instance type |
| `output` | outputs.tf — surfaces the public IP and SSH command after apply |
| `count` (conditional resources) | ec2.tf — only creates a new key pair if you didn't supply one |
| Local values (`locals`) | ec2.tf — picks between your key or the generated one |
| Resource dependencies | Terraform automatically sequences VPC → Subnet → IGW → Route Table → Security Group → EC2 based on the references between them |

## Suggested Next Steps
1. Move the instance into a **private** subnet with a separate **public**
   subnet + NAT Gateway, and use a bastion host for SSH (see the "Secure AWS
   Network Infrastructure" mini-project for a full example of this pattern).
2. Add an Elastic IP so the public IP doesn't change if the instance is
   stopped/started.
3. Replace password-less key-pair SSH with **AWS Systems Manager Session
   Manager**, which removes the need to open port 22 at all.
4. Parameterize the AMI filter to support Ubuntu or other distros via a
   variable.
