# Implementation Steps (Manual / AWS Console Reference)

The Terraform code in `terraform/` automates every step below. This is for
reference if you want to understand or demonstrate the manual process.

## 1. Create VPC
- AWS Console → VPC → "Create VPC"
- Name: `mini-project3-vpc`
- IPv4 CIDR: `10.0.0.0/16`

## 2. Create Subnet
- VPC → Subnets → "Create subnet"
- VPC: `mini-project3-vpc`
- Name: `mini-project3-subnet`
- Availability Zone: e.g. `us-east-1a`
- CIDR: `10.0.1.0/24`
- After creation: Actions → Edit subnet settings → Enable "Auto-assign
  public IPv4 address" (needed so the EC2 instance gets a public IP for SSH)

### Supporting steps (needed to actually reach the instance)
- Create an **Internet Gateway**, attach it to the VPC
- Create a **Route Table** with a `0.0.0.0/0` route pointing at the IGW,
  associate it with the subnet
- Create a **Security Group** allowing inbound TCP 22 (SSH) from your IP only

## 3. Launch EC2 using Terraform
```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars: set my_ip
terraform init
terraform apply
```
This launches an Amazon Linux 2023 `t2.micro` instance into the subnet, with
the security group attached and a public IP assigned.

(Manual console equivalent: EC2 → Launch instance → choose the VPC/subnet
above → attach the security group → select or create a key pair → Launch.)

## 4. Connect Through SSH
```bash
cd ../scripts
chmod +x connect_ssh.sh
./connect_ssh.sh
```
Or manually:
```bash
terraform -chdir=../terraform output -raw ssh_command
# copy and run the printed command, e.g.:
ssh -i generated_key.pem ec2-user@<public-ip>
```
