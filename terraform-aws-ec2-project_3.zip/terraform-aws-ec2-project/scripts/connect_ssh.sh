#!/bin/bash
# -----------------------------------------------------------------------------
# connect_ssh.sh
# TASK 4: Connect through SSH
#
# Reads the EC2 instance's public IP straight from Terraform's outputs and
# opens an interactive SSH session.
# -----------------------------------------------------------------------------
set -euo pipefail

TF_DIR="$(dirname "$0")/../terraform"
KEY_FILE="${KEY_FILE:-$TF_DIR/generated_key.pem}"
SSH_USER="${SSH_USER:-ec2-user}"

PUBLIC_IP=$(terraform -chdir="$TF_DIR" output -raw instance_public_ip 2>/dev/null)

if [[ -z "$PUBLIC_IP" ]]; then
  echo "Could not read the instance's public IP from Terraform outputs."
  echo "Make sure you've run 'terraform apply' successfully in the terraform/ directory."
  exit 1
fi

if [[ ! -f "$KEY_FILE" ]]; then
  echo "Key file not found at: $KEY_FILE"
  echo "If you used an existing key pair (key_name set in terraform.tfvars),"
  echo "set KEY_FILE=/path/to/your-key.pem and re-run this script."
  exit 1
fi

chmod 400 "$KEY_FILE" 2>/dev/null || true

echo "Connecting to $SSH_USER@$PUBLIC_IP ..."
ssh -o StrictHostKeyChecking=no -i "$KEY_FILE" "${SSH_USER}@${PUBLIC_IP}"
