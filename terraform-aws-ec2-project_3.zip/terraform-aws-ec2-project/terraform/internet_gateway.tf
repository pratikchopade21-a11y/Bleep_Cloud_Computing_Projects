# -----------------------------------------------------------------------------
# SUPPORTING RESOURCE: Internet Gateway
# Needed so the subnet (and the EC2 instance in it) can reach the internet -
# without this, "Connect through SSH" from your laptop would be impossible.
# -----------------------------------------------------------------------------
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = "${var.project_name}-igw"
  }
}
