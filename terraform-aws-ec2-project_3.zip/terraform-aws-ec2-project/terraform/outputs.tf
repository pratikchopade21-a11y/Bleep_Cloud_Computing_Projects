output "vpc_id" {
  description = "ID of the created VPC"
  value       = aws_vpc.main.id
}

output "subnet_id" {
  description = "ID of the created subnet"
  value       = aws_subnet.main.id
}

output "instance_id" {
  description = "ID of the launched EC2 instance"
  value       = aws_instance.main.id
}

output "instance_public_ip" {
  description = "Public IP of the EC2 instance"
  value       = aws_instance.main.public_ip
}

output "ssh_key_note" {
  description = "How to SSH in"
  value       = var.key_name == "" ? "A new key pair was generated: terraform/generated_key.pem (chmod 400 it before use)" : "Using your existing key pair: ${var.key_name}"
}

output "ssh_command" {
  description = "Ready-to-use SSH command"
  value       = var.key_name == "" ? "ssh -i generated_key.pem ec2-user@${aws_instance.main.public_ip}" : "ssh -i /path/to/${var.key_name}.pem ec2-user@${aws_instance.main.public_ip}"
}
