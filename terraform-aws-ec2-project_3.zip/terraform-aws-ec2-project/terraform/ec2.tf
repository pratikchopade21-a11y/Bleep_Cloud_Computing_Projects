# -----------------------------------------------------------------------------
# TASK 3: Launch EC2 using Terraform
# -----------------------------------------------------------------------------

# Latest Amazon Linux 2023 AMI (free-tier eligible)
data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# --- Key Pair -----------------------------------------------------------------
# If var.key_name is empty, generate a brand-new key pair automatically so the
# project works out of the box. Otherwise, reuse an existing key pair you own.
resource "tls_private_key" "generated" {
  count     = var.key_name == "" ? 1 : 0
  algorithm = "RSA"
  rsa_bits  = 4096
}

resource "aws_key_pair" "generated" {
  count      = var.key_name == "" ? 1 : 0
  key_name   = "${var.project_name}-key"
  public_key = tls_private_key.generated[0].public_key_openssh
}

resource "local_file" "private_key" {
  count           = var.key_name == "" ? 1 : 0
  content         = tls_private_key.generated[0].private_key_pem
  filename        = "${path.module}/generated_key.pem"
  file_permission = "0400"
}

locals {
  key_name = var.key_name != "" ? var.key_name : aws_key_pair.generated[0].key_name
}

resource "aws_instance" "main" {
  ami                         = data.aws_ami.amazon_linux.id
  instance_type               = var.instance_type
  subnet_id                   = aws_subnet.main.id
  vpc_security_group_ids      = [aws_security_group.ssh_access.id]
  key_name                    = local.key_name
  associate_public_ip_address = true

  tags = {
    Name = "${var.project_name}-ec2"
  }
}
