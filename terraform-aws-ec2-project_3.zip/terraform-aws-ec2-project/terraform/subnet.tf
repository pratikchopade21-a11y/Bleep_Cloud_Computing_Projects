# -----------------------------------------------------------------------------
# TASK 2: Create subnet
# -----------------------------------------------------------------------------
resource "aws_subnet" "main" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = var.subnet_cidr
  availability_zone       = var.availability_zone
  map_public_ip_on_launch = true # so the EC2 instance gets a public IP for SSH

  tags = {
    Name = "${var.project_name}-subnet"
  }
}
