# -----------------------------------------------------------------------------
# SUPPORTING RESOURCE: Route Table
# Routes all internet-bound traffic (0.0.0.0/0) from the subnet to the IGW.
# -----------------------------------------------------------------------------
resource "aws_route_table" "main" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }

  tags = {
    Name = "${var.project_name}-rt"
  }
}

resource "aws_route_table_association" "main" {
  subnet_id      = aws_subnet.main.id
  route_table_id = aws_route_table.main.id
}
