# Minor Project 3 – Terraform AWS Infrastructure Setup

## Objective
Use Terraform to provision a basic AWS network (VPC + subnet) and launch an
EC2 instance into it, then connect to that instance over SSH.

## Tools Used
- Terraform
- AWS EC2
- VPC

## Tasks Covered
1. Create VPC
2. Create subnet
3. Launch EC2 using Terraform
4. Connect through SSH

## Architecture
```
Internet
   │
   ▼
Internet Gateway
   │
   ▼
Route Table (0.0.0.0/0 → IGW)
   │
   ▼
VPC (10.0.0.0/16)
 └── Subnet (10.0.1.0/24)
      └── EC2 Instance (public IP, Security Group: SSH only from your IP)
```

A subnet on its own has no path to the internet, so this project also wires
up the minimum extra pieces needed to make SSH actually work end-to-end: an
Internet Gateway, a route table, and a Security Group. Without these three,
"Launch EC2" and "Connect through SSH" wouldn't be possible — they're the
supporting cast around the four tasks you were given.

## Repository Layout
```
terraform-aws-ec2-project/
├── README.md
├── terraform/
│   ├── provider.tf
│   ├── variables.tf
│   ├── vpc.tf              <- Task 1: Create VPC
│   ├── subnet.tf            <- Task 2: Create subnet
│   ├── internet_gateway.tf   (supporting: makes the subnet public)
│   ├── route_table.tf        (supporting: routes traffic to the IGW)
│   ├── security_group.tf     (supporting: allows SSH from your IP)
│   ├── ec2.tf               <- Task 3: Launch EC2 using Terraform
│   ├── outputs.tf
│   └── terraform.tfvars.example
├── scripts/
│   └── connect_ssh.sh       <- Task 4: Connect through SSH
└── docs/
    ├── implementation_steps.md
    └── learning_outcomes.md
```

## Prerequisites
1. An AWS account with programmatic access configured (`aws configure`).
2. [Terraform](https://developer.hashicorp.com/terraform/install) >= 1.5.
3. Your current public IP (to lock down SSH):
   ```bash
   curl -s https://checkip.amazonaws.com
   ```

## Quick Start

```bash
cd terraform

# 1. Copy the example variables file and edit it
cp terraform.tfvars.example terraform.tfvars
nano terraform.tfvars      # set my_ip (required); key_name optional

# 2. Initialize Terraform
terraform init

# 3. Review the plan
terraform plan

# 4/5/6. Create the VPC, subnet, IGW, route table, security group, and
# launch the EC2 instance - all in one command:
terraform apply
```

Type `yes` when prompted. Terraform prints the instance's public IP and a
ready-to-use SSH command when it finishes.

If you leave `key_name` blank in `terraform.tfvars`, Terraform automatically
generates a new SSH key pair for you and saves the private key as
`terraform/generated_key.pem`.

## Task 4: Connect Through SSH
```bash
cd ../scripts
chmod +x connect_ssh.sh
./connect_ssh.sh
```
This reads the instance's public IP straight from Terraform's outputs and
opens an SSH session automatically (using `generated_key.pem` if Terraform
created one, or the key you specified otherwise).

Or do it manually:
```bash
cd terraform
terraform output -raw ssh_command
# copy/paste the printed command
```

## Tearing Down
```bash
cd terraform
terraform destroy
```

## Learning Outcomes
See `docs/learning_outcomes.md` for a full write-up of what each Terraform
resource does and why it's needed.
